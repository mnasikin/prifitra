<?php
require_once "parts/main/header.php";
require_once "parts/main/nav.php";
require_once "parts/main/navbar.php";
?>
<div class="container-fluid pt-4 px-4">
    <div class="bg-secondary text-center rounded p-4 ">
        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                TO BE HONEST, THERE'S NO HELP AT ALL
            </div>
        </div>
    </div>
</div>
<?php
require "parts/main/widget.php";
require "parts/main/footer.php";
?> 