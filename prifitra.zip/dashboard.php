<?php
require_once "parts/main/header.php";
require_once "parts/main/nav.php";
require_once "parts/main/navbar.php";
require_once "parts/main/content.php";
require_once "parts/main/widget.php";
require_once "parts/main/footer.php";
?> 