<!DOCTYPE html>
<html lang="en">
<head>
	<title>PRIFITRA 1.0</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="./inc/login/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="./inc/login/css/extra.css">
	<link rel="stylesheet" type="text/css" href="./inc/login/css/styles.css">
</head>
